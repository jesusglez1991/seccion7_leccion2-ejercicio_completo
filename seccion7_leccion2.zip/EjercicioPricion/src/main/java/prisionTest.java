/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jose
 */
public class prisionTest {
    public static void main(String[] args) {
        prisioner bubba = new prisioner();
        prisioner twitch = new prisioner();
       //String s1 =  "bubba";
        //String s2 = "twitch";
   //bubba = twitch;
   //bubba.nombre = "Bubba";
   //twitch.nombre = "Twitch";
          
        
        System.out.println(bubba == twitch);
        //System.out.println(s1);
        // System.out.println(s2);
    }
}
